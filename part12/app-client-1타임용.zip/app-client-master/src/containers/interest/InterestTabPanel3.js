import React from "react";
import TabPanel from "../../components/Tabs/TabPanel";

class InterestTabPanel3 extends React.Component {
  render() {
    return (
      <TabPanel value={this.props.value} index={2}>
        3333
      </TabPanel>
    )
  }
}

export default InterestTabPanel3;