import React from "react";
import TabPanel from "../../components/Tabs/TabPanel";

class InterestTabPanel2 extends React.Component {
  render() {
    return (
      <TabPanel value={this.props.value} index={1}>
        2222
      </TabPanel>
    )
  }
}

export default InterestTabPanel2;