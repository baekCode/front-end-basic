const render = (element, container) => {
    container.innerHTML = element;
};

export {render};