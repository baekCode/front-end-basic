// import {render} from './Renderer';
// import App from "./App";
//
// render(App(), document.getElementById('app'));
import 'regenerator-runtime';
import React from 'react';
import ReactDOM from 'react-dom';
import App2 from "./App2";

ReactDOM.render(<App2 />, document.getElementById('app'));


